#!/usr/bin/env perl -w
use strict;

package CNC::Generator;

use POSIX;

use base 'Exporter';
our @EXPORT_OK = qw(createWordList upperLettersTransform nullTransform);

my @wordlist = qw(
  Defcon
  beer
  cracking
  hacking
  fucked
  krux
  gibson
  security
);

sub nullTransform($) {
  my ($text) = @_;

  return $text;
}

sub upperLettersTransform($) {
  my ($text) = @_;

  $text = uc $text;
  $text =~ s/[^A-Z ]//;
  return $text;
}

sub createWordList {
  my %args = (
    # If required provided, ensures that each word in required is in the results.
    required => [],
    wordTransform => \&nullTransform,
    endingChance => 0.1,
    @_
  );

  if (ref($args{required}) ne "ARRAY") {
    my @required = split " ", $args{required};
    $args{required} = \@required;
  }
  my %required = map { upperLettersTransform($_) => 1 } @{$args{required}};

  # Include the wordlist, any required words, and empty words (to generate multiple spaces). Uppercase everything and cut out
  # letters other than uppercase or space.
  my @words = map { upperLettersTransform($_) } @wordlist, @{$args{required}}, '';

  my @result = ();
  while (1) {
    my $word = $words[int(rand(scalar(@words)))];
    push @result, $word;

    if (exists($required{$word})) {
      delete $required{$word};
    }

    # If we have all of the required words, then roll the dice to see if we are finished.
    if (scalar(keys(%required)) == 0) {
      last if rand() < $args{endingChance};
    }
  }

  return wantarray ? @result : join(' ', @result);
}

